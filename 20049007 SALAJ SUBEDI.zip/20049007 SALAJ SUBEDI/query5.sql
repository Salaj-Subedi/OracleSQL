 select painting_id, fo.order_date, (sysdate-Order_date)/30 as "Inactive months" from finalorder fo  where (sysdate - Order_date)/30 >= 4;

