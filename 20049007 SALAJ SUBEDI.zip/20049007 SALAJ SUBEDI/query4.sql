 select p.painting_id, Theme ,order_date, Customer_name from finalorder fo join paintings p on p.painting_id= fo.painting_id
  join customer c on c.customer_id = fo.customer_id where c.customer_id = '007C' and fo.order_type = 'rent';

