select p.Painting_id , Theme , Rental_price, sell_price , Hire_date , A.artist_id , Artist_name, fo.Order_date as LastOrder from paintings p join FinalOrder fo on fo.painting_id=p.painting_id join Artists a on a.artist_id=p.artist_id where (sysdate-Order_date)/30 >3;

