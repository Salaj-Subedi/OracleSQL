 select Painting_id ,a.Artist_id , Rental_price , (Rental_price * 0.2)  as PaidPrice from Paintings P Join Artists a on a.Artist_id= P.Artist_id;

