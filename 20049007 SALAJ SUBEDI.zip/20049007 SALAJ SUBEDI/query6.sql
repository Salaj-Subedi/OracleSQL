select p.painting_id, p.rental_price, p.theme, fo.order_date as LastActive, (sysdate-Order_date)/30 as InactiveMonths from finalorder fo join paintings p on p.painting_id  = fo.painting_id where (sysdate-Order_date)/30 >=1 ;

