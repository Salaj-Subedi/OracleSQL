 select customer_id , Customer_name ,Customer_type , "Discount%" from customer order by Customer_type;

