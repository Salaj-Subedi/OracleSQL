 select c.customer_id,customer_name, count(order_total) as Orders_Made
from finalorder fo join customer c on c.customer_id = fo.customer_id where
order_type = 'rent' group by c.customer_id,customer_name having
count(distinct order_id)>4;

