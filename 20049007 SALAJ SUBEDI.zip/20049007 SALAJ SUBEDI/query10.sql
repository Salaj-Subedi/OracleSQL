select a.artist_name ,sum(order_total) as Total_Sold from finalorder fo join paintings p on p.painting_id = fo.painting_id join Artists a on a.artist_id = p.artist_id where fo.order_type='sell' and months_between(order_date,sysdate)<=1 group by a.artist_name ;

